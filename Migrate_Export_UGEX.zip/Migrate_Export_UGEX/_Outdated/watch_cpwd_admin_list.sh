watch -d -n 1 "cpwd_admin list"
