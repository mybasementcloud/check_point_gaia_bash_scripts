watch -d -n 1 "mdsstat"
